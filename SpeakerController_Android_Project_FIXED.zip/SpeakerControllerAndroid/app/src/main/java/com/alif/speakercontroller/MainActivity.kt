package com.alif.speakercontroller

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.*
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 14, 26)
    private val panel = Color.rgb(22, 32, 51)
    private val accent = Color.rgb(65, 190, 220)
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private lateinit var audioManager: AudioManager
    private lateinit var root: LinearLayout
    private lateinit var deviceList: LinearLayout
    private lateinit var btStatus: TextView
    private lateinit var trackLabel: TextView
    private lateinit var playButton: Button
    private lateinit var volumeSeek: SeekBar
    private var mediaPlayer: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private var selectedUri: Uri? = null
    private var receiverRegistered = false
    private val discovered = linkedMapOf<String, BluetoothDevice>()
    private val requestCodeBt = 2201
    private val requestCodeAudio = 2202

    private val btReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device = if (Build.VERSION.SDK_INT >= 33)
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    else @Suppress("DEPRECATION") (intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE))
                    if (device != null) {
                        val address = safeAddress(device) ?: return
                        discovered[address] = device
                        renderDevices()
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> setStatus("Scan শেষ হয়েছে")
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> renderDevices()
                BluetoothAdapter.ACTION_STATE_CHANGED -> updateBluetoothState()
                BluetoothA2dpCompat.ACTION_STATE -> updateConnectionStatus()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = manager.adapter ?: run {
            Toast.makeText(this, "এই ফোনে Bluetooth নেই", Toast.LENGTH_LONG).show()
            finish(); return
        }
        buildUi()
        registerBtReceiver()
        updateBluetoothState()
        updateConnectionStatus()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(28))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        text(root, "SPEAKER CONTROLLER", 22, Color.WHITE, true)
        text(root, "SMART AUDIO  •  HS 862", 11, Color.LTGRAY)
        btStatus = text(root, "Bluetooth status checking…", 14, accent, true)
        section("Bluetooth Devices")
        rowButton(root, "Scan nearby devices", "Open Bluetooth settings") {
            if (hasBtPermissions()) startScan() else requestBtPermissions()
        }.also { it.second.setOnClickListener { openBluetoothSettings() } }
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList)
        section("Music Player")
        trackLabel = text(root, "কোনো গান নির্বাচন করা হয়নি", 13, Color.LTGRAY)
        rowButton(root, "Choose audio file", "Play / Pause") {
            chooseAudio()
        }.also { pair ->
            playButton = pair.second
            playButton.setOnClickListener { togglePlayback() }
        }
        rowButton(root, "Previous", "Next") {
            Toast.makeText(this, "একটি ফাইল নির্বাচন করে চালান", Toast.LENGTH_SHORT).show()
        }.also { pair ->
            pair.first.setOnClickListener { Toast.makeText(this, "একটি ফাইল নির্বাচন করে চালান", Toast.LENGTH_SHORT).show() }
            pair.second.setOnClickListener { Toast.makeText(this, "একক ফাইল প্লেয়ারে Next নেই", Toast.LENGTH_SHORT).show() }
        }
        text(root, "Player volume", 13, Color.WHITE, true)
        volumeSeek = SeekBar(this).apply {
            max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            progress = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(volumeSeek)
        section("Equalizer")
        text(root, "এই Equalizer শুধু এই অ্যাপের Local Music Player-এ কাজ করে।", 12, Color.LTGRAY)
        rowButton(root, "Bass +", "Bass −") {
            adjustEq(0, 300)
        }.also { pair -> pair.second.setOnClickListener { adjustEq(0, -300) } }
        rowButton(root, "Treble +", "Treble −") {
            adjustEq(-1, 300)
        }.also { pair -> pair.second.setOnClickListener { adjustEq(-1, -300) } }
        section("YouTube")
        val urlInput = EditText(this).apply {
            hint = "YouTube video URL"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(true); setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(panel, 12)
        }
        root.addView(urlInput, matchWrap())
        rowButton(root, "Play in app", "Open YouTube") {
            val id = extractYouTubeId(urlInput.text.toString())
            if (id == null) Toast.makeText(this, "সঠিক YouTube URL দিন", Toast.LENGTH_LONG).show()
            else showYouTube(id)
        }.also { pair ->
            pair.second.setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" +
                    Uri.encode(urlInput.text.toString().ifBlank { "music" }))))
            }
        }
        section("HS 862 Hardware Buttons")
        text(root, "MIC-MUTE, ECHO এবং MUSIC ONLY স্পিকারের নিজস্ব কমান্ড। HS 862-এর control protocol জানা না থাকায় এই অ্যাপ এগুলো নিয়ন্ত্রণ করছে না। স্পিকারের physical button ব্যবহার করুন।", 12, Color.rgb(245, 207, 143))
        renderDevices()
    }

    private fun section(title: String) {
        val t = text(root, title, 17, Color.WHITE, true)
        t.setPadding(0, dp(22), 0, dp(8))
    }

    private fun text(parent: LinearLayout, value: String, size: Int, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
        }
        parent.addView(t, matchWrap())
        return t
    }

    private fun rowButton(parent: LinearLayout, left: String, right: String, action: () -> Unit): Pair<Button, Button> {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val a = button(left); val b = button(right)
        row.addView(a, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(5) })
        row.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(5) })
        parent.addView(row, matchWrap())
        a.setOnClickListener { action() }
        return a to b
    }

    private fun button(label: String) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false
        setTextColor(Color.WHITE); background = rounded(Color.rgb(38, 58, 88), 12)
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(8) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun setStatus(s: String) { btStatus.text = s }

    private fun requiredBtPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasBtPermissions(): Boolean =
        requiredBtPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun requestBtPermissions() {
        requestPermissions(requiredBtPermissions(), requestCodeBt)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestCodeBt) {
            if (hasBtPermissions()) startScan()
            else Toast.makeText(this, "Bluetooth permission না দিলে Scan করা যাবে না", Toast.LENGTH_LONG).show()
        }
    }

    private fun startScan() {
        if (!hasBtPermissions()) { requestBtPermissions(); return }
        if (!bluetoothAdapter.isEnabled) {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return
        }
        try {
            if (bluetoothAdapter.isDiscovering) bluetoothAdapter.cancelDiscovery()
            discovered.clear()
            bluetoothAdapter.bondedDevices.forEach { d -> safeAddress(d)?.let { discovered[it] = d } }
            renderDevices()
            setStatus("ডিভাইস খোঁজা হচ্ছে…")
            val started = bluetoothAdapter.startDiscovery()
            if (!started) setStatus("Scan শুরু হয়নি; Bluetooth Settings খুলুন")
        } catch (e: SecurityException) {
            setStatus("Bluetooth permission প্রয়োজন")
        }
    }

    private fun safeAddress(device: BluetoothDevice): String? =
        try { device.address } catch (_: SecurityException) { null }

    private fun safeName(device: BluetoothDevice): String =
        try { device.name ?: "Unknown device" } catch (_: SecurityException) { "Bluetooth device" }

    private fun renderDevices() {
        if (!::deviceList.isInitialized) return
        deviceList.removeAllViews()
        if (hasBtPermissions()) {
            try {
                bluetoothAdapter.bondedDevices.forEach { d -> safeAddress(d)?.let { discovered[it] = d } }
            } catch (_: SecurityException) {}
        }
        if (discovered.isEmpty()) {
            val empty = TextView(this).apply {
                text = "কোনো ডিভাইস এখনো পাওয়া যায়নি। Scan nearby devices চাপুন।"
                setTextColor(Color.LTGRAY); textSize = 12f
            }
            deviceList.addView(empty)
        }
        discovered.values.forEach { device ->
            val address = safeAddress(device) ?: return@forEach
            val bonded = try { device.bondState == BluetoothDevice.BOND_BONDED } catch (_: SecurityException) { false }
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(6), dp(8))
                background = rounded(panel, 12)
            }
            val label = TextView(this).apply {
                text = safeName(device) + "\n" + address + if (bonded) "\nPaired" else "\nNot paired"
                textSize = 12f; setTextColor(Color.WHITE)
            }
            item.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val action = button(if (bonded) "Paired" else "Pair")
            action.isEnabled = !bonded
            action.setOnClickListener { pairDevice(device) }
            item.addView(action)
            val lp = matchWrap()
            deviceList.addView(item, lp)
        }
    }

    private fun pairDevice(device: BluetoothDevice) {
        if (!hasBtPermissions()) { requestBtPermissions(); return }
        try {
            if (bluetoothAdapter.isDiscovering) bluetoothAdapter.cancelDiscovery()
            val ok = device.createBond()
            Toast.makeText(this, if (ok) "Android pairing request পাঠানো হয়েছে" else "Pairing শুরু করা যায়নি", Toast.LENGTH_LONG).show()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Bluetooth permission প্রয়োজন", Toast.LENGTH_LONG).show()
        }
    }

    private fun updateBluetoothState() {
        if (!::btStatus.isInitialized) return
        setStatus(if (bluetoothAdapter.isEnabled) "Bluetooth ON • HS 862-এর audio route ফোনে নির্বাচন করুন" else "Bluetooth OFF")
    }

    private fun updateConnectionStatus() {
        // Pairing is not the same as an active A2DP audio connection.
        // This UI intentionally avoids claiming connected without profile confirmation.
        if (!::btStatus.isInitialized || !bluetoothAdapter.isEnabled) return
        setStatus("Bluetooth ON • Connected audio output Android-এ যাচাই করুন")
    }

    private fun openBluetoothSettings() {
        startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
    }

    private fun registerBtReceiver() {
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(btReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(btReceiver, filter)
        receiverRegistered = true
    }

    private fun chooseAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        startActivityForResult(intent, requestCodeAudio)
    }

    @Deprecated("Legacy activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCodeAudio && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            selectedUri = uri
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            val name = queryDisplayName(uri) ?: "Selected audio"
            trackLabel.text = name
            startAudio(uri)
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun startAudio(uri: Uri) {
        try {
            mediaPlayer?.release()
            equalizer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioStreamType(AudioManager.STREAM_MUSIC)
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { mp ->
                    mp.start()
                    playButton.text = "Pause"
                    try {
                        equalizer = Equalizer(0, mp.audioSessionId).apply {
                            enabled = true
                        }
                    } catch (_: Exception) {
                        Toast.makeText(this@MainActivity, "এই ফোনে Equalizer সমর্থিত নয়", Toast.LENGTH_SHORT).show()
                    }
                }
                setOnCompletionListener { playButton.text = "Play" }
                setOnErrorListener { _, what, extra ->
                    playButton.text = "Play"
                    Toast.makeText(this@MainActivity, "Audio error: $what / $extra", Toast.LENGTH_LONG).show()
                    true
                }
                prepareAsync()
            }
            playButton.text = "Loading…"
        } catch (e: Exception) {
            Toast.makeText(this, "অডিও খোলা যায়নি: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun togglePlayback() {
        val p = mediaPlayer
        if (p == null) {
            chooseAudio()
            return
        }
        try {
            if (p.isPlaying) { p.pause(); playButton.text = "Play" }
            else { p.start(); playButton.text = "Pause" }
        } catch (e: Exception) {
            Toast.makeText(this, "Player প্রস্তুত নয়", Toast.LENGTH_SHORT).show()
        }
    }

    private fun adjustEq(bandIndex: Int, delta: Int) {
        val eq = equalizer
        if (eq == null) {
            Toast.makeText(this, "প্রথমে Local Music চালান", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val range = eq.bandLevelRange
            val band: Short = if (bandIndex == 0) {
                (0 until eq.numberOfBands).firstOrNull { eq.getCenterFreq(it.toShort()) < 250000 }?.toShort() ?: 0
            } else {
                (0 until eq.numberOfBands).lastOrNull { eq.getCenterFreq(it.toShort()) > 3000000 }?.toShort() ?: (eq.numberOfBands - 1).toShort()
            }
            val current = eq.getBandLevel(band).toInt()
            val next = (current + delta).coerceIn(range[0].toInt(), range[1].toInt())
            eq.setBandLevel(band, next.toShort())
            Toast.makeText(this, "Equalizer updated", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Equalizer পরিবর্তন করা যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    private fun extractYouTubeId(raw: String): String? {
        return try {
            val uri = Uri.parse(raw.trim())
            val host = uri.host?.lowercase()?.removePrefix("www.") ?: return null
            val id = when {
                host == "youtu.be" -> uri.lastPathSegment
                host.endsWith("youtube.com") && uri.path == "/watch" -> uri.getQueryParameter("v")
                host.endsWith("youtube.com") -> {
                    val parts = uri.pathSegments
                    if (parts.size >= 2 && parts[0] in listOf("embed", "shorts", "live")) parts[1] else null
                }
                else -> null
            }
            if (id != null && id.matches(Regex("[A-Za-z0-9_-]{11}"))) id else null
        } catch (_: Exception) { null }
    }

    private fun showYouTube(videoId: String) {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("https://www.youtube.com/embed/$videoId?playsinline=1&rel=0")
        web.setOnLongClickListener { false }
        web.isLongClickable = true
    }

    override fun onDestroy() {
        try { if (bluetoothAdapter.isDiscovering) bluetoothAdapter.cancelDiscovery() } catch (_: Exception) {}
        if (receiverRegistered) try { unregisterReceiver(btReceiver) } catch (_: Exception) {}
        mediaPlayer?.release()
        equalizer?.release()
        super.onDestroy()
    }
}

private object BluetoothA2dpCompat {
    const val ACTION_STATE = "android.bluetooth.a2dp.profile.action.CONNECTION_STATE_CHANGED"
}
