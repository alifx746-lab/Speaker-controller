# Speaker Controller — HS 862 (Android)

এটি HTML নয়, একটি Native Android/Kotlin project।

## এই সংস্করণে বাস্তব ফিচার
- Android Bluetooth Classic device discovery (Nearby devices permission সহ)
- আগে থেকে paired device তালিকায় দেখানো
- Android system pairing flow শুরু করতে `createBond()`
- Android Bluetooth Settings খোলার shortcut
- ফোনে থাকা audio file বেছে MediaPlayer দিয়ে চালানো
- Android system music volume নিয়ন্ত্রণ
- Local player-এর audio session-এ Android Equalizer ব্যবহার করার চেষ্টা
- YouTube official embedded player

## গুরুত্বপূর্ণ সীমাবদ্ধতা
1. Pairing মানেই A2DP audio connected নয়। Android/ফোনের Bluetooth system audio route ঠিক করে।
2. সাধারণ third-party app Android-এর privileged A2DP connection API ব্যবহার করতে পারে না। এই অ্যাপ তাই মিথ্যা “Connected” দেখায় না; Pairing এবং audio route আলাদা করে।
3. HS 862-এর MIC-MUTE, ECHO, MUSIC ONLY, M/T-এর Bluetooth command protocol জানা নেই। তাই সেগুলো অ্যাপে fake করা হয়নি।
4. Equalizer সব ফোনে সমানভাবে কাজ নাও করতে পারে; কিছু ডিভাইস Equalizer effect block/override করে।
5. YouTube embedded playback YouTube-এর নিয়ম ও ভিডিওর embed permission-এর ওপর নির্ভর করে।

## APK বানানোর সহজ উপায়: GitHub Actions (কম্পিউটার/মোবাইল ব্রাউজার)
1. GitHub-এ নতুন repository তৈরি করো।
2. এই ZIP extract করে সব ফাইল repository-তে upload করো।
3. `.github/workflows/build.yml` ফাইলটি commit করো।
4. GitHub repository → Actions → Android APK Build → Run workflow।
5. Workflow শেষ হলে Artifacts থেকে `SpeakerController-debug-apk` download করো।
6. ZIP extract করে `app-debug.apk` Android ফোনে install করো।

## Android Studio দিয়ে
- Android Studio-তে project folder open করো।
- Android SDK Platform 35 ইনস্টল করো।
- JDK 17 ব্যবহার করো।
- Build → Build APK(s) নির্বাচন করো।
- APK path: `app/build/outputs/apk/debug/app-debug.apk`

## প্রথমবার ব্যবহার
1. ফোনের Bluetooth চালু করো এবং HS 862 চালু রাখো।
2. অ্যাপ খুলে Nearby devices permission Allow করো।
3. Scan nearby devices চাপো।
4. HS 862 পেলে Pair চাপো এবং Android-এর pairing prompt অনুমোদন করো।
5. অডিও শোনার জন্য Android Quick Settings-এর Media output/Audio output থেকে HS 862 নির্বাচন করো, অথবা Bluetooth Settings-এ connected audio device নিশ্চিত করো।
6. Music Player → Choose audio file থেকে একটি গান নির্বাচন করো।

## প্রযুক্তি
- Kotlin
- Android Bluetooth API
- MediaPlayer
- Android Equalizer effect
- WebView + YouTube embed
